/*
 * Gmail Reader (GMan -- The Gmail Postman)
 * 
 * This application creates your own Gmail Notifier kind of application that checks the new mails using recently 
 * introduced Gmail Atom Feeds and speaks the details of the mail using Microsoft Agent.
 * 
 * Author: Anup Shinde
 * Email:  anup@micromacs.com
 * 
 * */

using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace GMReader
{
	/// <summary>
	/// Summary description for frmProxyConfigure.
	/// </summary>
	public class frmProxyConfigure : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.GroupBox grpCaption;
		internal System.Windows.Forms.TextBox txtProxyDomain;
		internal System.Windows.Forms.TextBox txtProxyServer;
		internal System.Windows.Forms.TextBox txtProxyPassword;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.Label Label6;
		internal System.Windows.Forms.CheckBox chkUseProxy;
		internal System.Windows.Forms.Button cmdOK;
		internal System.Windows.Forms.Label Label5;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.TextBox txtProxyUser;
		internal System.Windows.Forms.TextBox txtPort;
		internal System.Windows.Forms.Button cmdCancel;
		internal System.Windows.Forms.Label Label2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmProxyConfigure()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.grpCaption = new System.Windows.Forms.GroupBox();
			this.txtProxyDomain = new System.Windows.Forms.TextBox();
			this.txtProxyServer = new System.Windows.Forms.TextBox();
			this.txtProxyPassword = new System.Windows.Forms.TextBox();
			this.Label1 = new System.Windows.Forms.Label();
			this.Label6 = new System.Windows.Forms.Label();
			this.chkUseProxy = new System.Windows.Forms.CheckBox();
			this.cmdOK = new System.Windows.Forms.Button();
			this.Label5 = new System.Windows.Forms.Label();
			this.Label3 = new System.Windows.Forms.Label();
			this.txtProxyUser = new System.Windows.Forms.TextBox();
			this.txtPort = new System.Windows.Forms.TextBox();
			this.cmdCancel = new System.Windows.Forms.Button();
			this.Label2 = new System.Windows.Forms.Label();
			this.grpCaption.SuspendLayout();
			this.SuspendLayout();
			// 
			// grpCaption
			// 
			this.grpCaption.Controls.Add(this.txtProxyDomain);
			this.grpCaption.Controls.Add(this.txtProxyServer);
			this.grpCaption.Controls.Add(this.txtProxyPassword);
			this.grpCaption.Controls.Add(this.Label1);
			this.grpCaption.Controls.Add(this.Label6);
			this.grpCaption.Controls.Add(this.chkUseProxy);
			this.grpCaption.Controls.Add(this.cmdOK);
			this.grpCaption.Controls.Add(this.Label5);
			this.grpCaption.Controls.Add(this.Label3);
			this.grpCaption.Controls.Add(this.txtProxyUser);
			this.grpCaption.Controls.Add(this.txtPort);
			this.grpCaption.Controls.Add(this.cmdCancel);
			this.grpCaption.Controls.Add(this.Label2);
			this.grpCaption.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.grpCaption.ForeColor = System.Drawing.Color.Maroon;
			this.grpCaption.Location = new System.Drawing.Point(0, 0);
			this.grpCaption.Name = "grpCaption";
			this.grpCaption.Size = new System.Drawing.Size(336, 160);
			this.grpCaption.TabIndex = 14;
			this.grpCaption.TabStop = false;
			// 
			// txtProxyDomain
			// 
			this.txtProxyDomain.AutoSize = false;
			this.txtProxyDomain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtProxyDomain.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtProxyDomain.Location = new System.Drawing.Point(96, 96);
			this.txtProxyDomain.Name = "txtProxyDomain";
			this.txtProxyDomain.Size = new System.Drawing.Size(232, 20);
			this.txtProxyDomain.TabIndex = 4;
			this.txtProxyDomain.Text = "";
			// 
			// txtProxyServer
			// 
			this.txtProxyServer.AutoSize = false;
			this.txtProxyServer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtProxyServer.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtProxyServer.Location = new System.Drawing.Point(96, 16);
			this.txtProxyServer.Name = "txtProxyServer";
			this.txtProxyServer.Size = new System.Drawing.Size(120, 20);
			this.txtProxyServer.TabIndex = 0;
			this.txtProxyServer.Text = "";
			// 
			// txtProxyPassword
			// 
			this.txtProxyPassword.AutoSize = false;
			this.txtProxyPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtProxyPassword.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtProxyPassword.Location = new System.Drawing.Point(96, 72);
			this.txtProxyPassword.Name = "txtProxyPassword";
			this.txtProxyPassword.PasswordChar = '*';
			this.txtProxyPassword.Size = new System.Drawing.Size(232, 20);
			this.txtProxyPassword.TabIndex = 3;
			this.txtProxyPassword.Text = "";
			// 
			// Label1
			// 
			this.Label1.AutoSize = true;
			this.Label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Label1.ForeColor = System.Drawing.Color.Navy;
			this.Label1.Location = new System.Drawing.Point(8, 40);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(63, 16);
			this.Label1.TabIndex = 3;
			this.Label1.Text = "User Name";
			// 
			// Label6
			// 
			this.Label6.AutoSize = true;
			this.Label6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Label6.ForeColor = System.Drawing.Color.Navy;
			this.Label6.Location = new System.Drawing.Point(224, 16);
			this.Label6.Name = "Label6";
			this.Label6.Size = new System.Drawing.Size(27, 16);
			this.Label6.TabIndex = 12;
			this.Label6.Text = "Port";
			// 
			// chkUseProxy
			// 
			this.chkUseProxy.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.chkUseProxy.ForeColor = System.Drawing.Color.Navy;
			this.chkUseProxy.Location = new System.Drawing.Point(8, 128);
			this.chkUseProxy.Name = "chkUseProxy";
			this.chkUseProxy.Size = new System.Drawing.Size(152, 24);
			this.chkUseProxy.TabIndex = 5;
			this.chkUseProxy.Text = "&Use these settings";
			// 
			// cmdOK
			// 
			this.cmdOK.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.cmdOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cmdOK.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cmdOK.ForeColor = System.Drawing.Color.Navy;
			this.cmdOK.Location = new System.Drawing.Point(168, 128);
			this.cmdOK.Name = "cmdOK";
			this.cmdOK.Size = new System.Drawing.Size(80, 23);
			this.cmdOK.TabIndex = 6;
			this.cmdOK.Text = "OK";
			this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
			// 
			// Label5
			// 
			this.Label5.AutoSize = true;
			this.Label5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Label5.ForeColor = System.Drawing.Color.Navy;
			this.Label5.Location = new System.Drawing.Point(8, 16);
			this.Label5.Name = "Label5";
			this.Label5.Size = new System.Drawing.Size(74, 16);
			this.Label5.TabIndex = 7;
			this.Label5.Text = "Proxy Server";
			// 
			// Label3
			// 
			this.Label3.AutoSize = true;
			this.Label3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Label3.ForeColor = System.Drawing.Color.Navy;
			this.Label3.Location = new System.Drawing.Point(8, 72);
			this.Label3.Name = "Label3";
			this.Label3.Size = new System.Drawing.Size(58, 16);
			this.Label3.TabIndex = 5;
			this.Label3.Text = "Password";
			// 
			// txtProxyUser
			// 
			this.txtProxyUser.AutoSize = false;
			this.txtProxyUser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtProxyUser.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtProxyUser.Location = new System.Drawing.Point(96, 40);
			this.txtProxyUser.Name = "txtProxyUser";
			this.txtProxyUser.Size = new System.Drawing.Size(232, 20);
			this.txtProxyUser.TabIndex = 2;
			this.txtProxyUser.Text = "";
			// 
			// txtPort
			// 
			this.txtPort.AutoSize = false;
			this.txtPort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtPort.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtPort.Location = new System.Drawing.Point(264, 16);
			this.txtPort.MaxLength = 6;
			this.txtPort.Name = "txtPort";
			this.txtPort.Size = new System.Drawing.Size(64, 20);
			this.txtPort.TabIndex = 1;
			this.txtPort.Text = "";
			// 
			// cmdCancel
			// 
			this.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cmdCancel.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cmdCancel.ForeColor = System.Drawing.Color.Navy;
			this.cmdCancel.Location = new System.Drawing.Point(248, 128);
			this.cmdCancel.Name = "cmdCancel";
			this.cmdCancel.Size = new System.Drawing.Size(80, 23);
			this.cmdCancel.TabIndex = 7;
			this.cmdCancel.Text = "Cancel";
			this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
			// 
			// Label2
			// 
			this.Label2.AutoSize = true;
			this.Label2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Label2.ForeColor = System.Drawing.Color.Navy;
			this.Label2.Location = new System.Drawing.Point(8, 96);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(46, 16);
			this.Label2.TabIndex = 4;
			this.Label2.Text = "&Domain";
			// 
			// frmProxyConfigure
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.WhiteSmoke;
			this.ClientSize = new System.Drawing.Size(338, 162);
			this.Controls.Add(this.grpCaption);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmProxyConfigure";
			this.Text = "Configure Proxy";
			this.Load += new System.EventHandler(this.frmProxyConfigure_Load);
			this.grpCaption.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void cmdOK_Click(object sender, System.EventArgs e)
		{

			clsMain.g_UseProxy=chkUseProxy.Checked;
			clsMain.g_proxyDomain = txtProxyDomain.Text.Trim();
			clsMain.g_proxyPassword = txtProxyPassword.Text.Trim();
			clsMain.g_proxyPort = txtPort.Text.Trim()==""?0:Convert.ToInt32(txtPort.Text.Trim());
			clsMain.g_UseProxy = chkUseProxy.Checked;
			clsMain.g_proxyServer = txtProxyServer.Text.Trim();
			clsMain.g_proxyUser = txtProxyUser.Text.Trim();
			clsMain.WriteOptions();
			this.DialogResult = DialogResult.OK;
			this.Close();

		}


		private void cmdCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void frmProxyConfigure_Load(object sender, System.EventArgs e)
		{
			chkUseProxy.Checked=clsMain.g_UseProxy;
			txtProxyDomain.Text=clsMain.g_proxyDomain;
			txtProxyPassword.Text=clsMain.g_proxyPassword;
			txtPort.Text=clsMain.g_proxyPort.ToString();
			chkUseProxy.Checked=clsMain.g_UseProxy;
			txtProxyServer.Text=clsMain.g_proxyServer;
			txtProxyUser.Text=clsMain.g_proxyUser;
		}


	}
}
