/* References

 -- http://smus.com/oauth2-chrome-extensions/

 -- http://wiki.developerforce.com/page/Digging_Deeper_into_OAuth_2.0_on_Force.com

*/



var sfdcAuth; // Holds the Auth2 object

chrome.app._inject_scope = "data_explorer_test"; /* This is used to determine what popup windows to close from this application. This must match the content_scripts->"matches" .If it does not match, the popups will stay open */
/* Another and a better way to do this is to use the application id and change the oauth2 lib to tackle this - but we don't want to change the lib for now. Also it would be a good thing to create an autonomous client instead of the injection workaround - We'll keep it for later. */

function docReady() {
	sfdcAuth = new OAuth2('sfdc', {
	//TODO= change clientid and secret 
	  client_id: '--YOUR_CONSUMER_KEY--',
	  client_secret: '--CONSUMER_SECRET--',
	  api_scope: 'full'
	});

	sfdcAuth.authorize(function(error) {
		if(typeof(error)!='undefined') {
			//console.log('Callback object');
			alert(error);
		}
		
		var _data_service_url = sfdcAuth.get('instance_url') 
											+"/services/data/v26.0/query/?q=SELECT Name FROM Account LIMIT 100"; 
											//+ '?oauth_token=' + sfdcAuth.getAccessToken();
		
		$.ajax({
			url: _data_service_url,
			cache: false,
			type: 'GET',
			dataType: 'json',
			headers: {'Authorization': 'OAuth ' + sfdcAuth.getAccessToken()},
			//data: data,
			success:  function(data){
				console.log(data);
				var source   = $("#accounts-list-template").html();
				t_accounts = Handlebars.compile(source);
				var html = t_accounts(data);
				$("#content").append(html);
			}
		});

		//alert('OAuth ' + myAuth.getAccessToken());
	});	
	
	$("#clearToken").click(function() { 
		alert('Please logout of any existing SF sessions to use an another account');
		sfdcAuth.clearAccessToken(); 
		location.reload();
	});
}

$(docReady);