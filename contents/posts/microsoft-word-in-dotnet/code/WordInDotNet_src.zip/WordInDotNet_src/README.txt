

Please follow the following steps to get a proper design view of the project.

Open up the solution file in the directory "WordInDotNet" in VS.NET 2003

Rebuild or execute the complete solution once and close VS.NET.

Open the solution file again to see a proper design view. 
This occurs because the control is directly taken from the build directories.


The "Sample.dot" file can be used to see the bookmarking sample