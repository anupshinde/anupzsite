using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WordInDOTNET
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private WinWordControl.WinWordControl objWinWordControl;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtClientName;
		private System.Windows.Forms.TextBox txtRecNo;
		private System.Windows.Forms.Button btnClientName;
		private System.Windows.Forms.Button btnRecNo;
		private System.Windows.Forms.Button btnCurrentDate;
		private System.Windows.Forms.Button btnMarkError;
		private System.Windows.Forms.Button btnRemoveError;
		private System.Windows.Forms.Button btnSaveDocument;
		private System.Windows.Forms.Button btnRemoveBookMarks;
		private System.Windows.Forms.Button btnPrintView;
		private System.Windows.Forms.Button btnNormalView;
		private System.Windows.Forms.Button btnWebView;
		private System.Windows.Forms.Button btnShowMenuBar;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.objWinWordControl = new WinWordControl.WinWordControl();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.txtClientName = new System.Windows.Forms.TextBox();
			this.txtRecNo = new System.Windows.Forms.TextBox();
			this.btnClientName = new System.Windows.Forms.Button();
			this.btnRecNo = new System.Windows.Forms.Button();
			this.btnCurrentDate = new System.Windows.Forms.Button();
			this.btnMarkError = new System.Windows.Forms.Button();
			this.btnRemoveError = new System.Windows.Forms.Button();
			this.btnSaveDocument = new System.Windows.Forms.Button();
			this.btnRemoveBookMarks = new System.Windows.Forms.Button();
			this.btnPrintView = new System.Windows.Forms.Button();
			this.btnNormalView = new System.Windows.Forms.Button();
			this.btnWebView = new System.Windows.Forms.Button();
			this.btnShowMenuBar = new System.Windows.Forms.Button();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(16, 8);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(96, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "Load Document";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// objWinWordControl
			// 
			this.objWinWordControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.objWinWordControl.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.objWinWordControl.Location = new System.Drawing.Point(168, 0);
			this.objWinWordControl.Name = "objWinWordControl";
			this.objWinWordControl.Size = new System.Drawing.Size(544, 517);
			this.objWinWordControl.TabIndex = 3;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 48);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(80, 16);
			this.label1.TabIndex = 4;
			this.label1.Text = "Client\'s Name";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 104);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(88, 16);
			this.label2.TabIndex = 5;
			this.label2.Text = "Record Number";
			// 
			// txtClientName
			// 
			this.txtClientName.Location = new System.Drawing.Point(16, 64);
			this.txtClientName.Name = "txtClientName";
			this.txtClientName.TabIndex = 6;
			this.txtClientName.Text = "Some Name";
			// 
			// txtRecNo
			// 
			this.txtRecNo.Location = new System.Drawing.Point(16, 120);
			this.txtRecNo.Name = "txtRecNo";
			this.txtRecNo.TabIndex = 7;
			this.txtRecNo.Text = "456789123";
			// 
			// btnClientName
			// 
			this.btnClientName.Location = new System.Drawing.Point(120, 64);
			this.btnClientName.Name = "btnClientName";
			this.btnClientName.Size = new System.Drawing.Size(32, 16);
			this.btnClientName.TabIndex = 9;
			this.btnClientName.Text = "-->";
			this.btnClientName.Click += new System.EventHandler(this.btnClientName_Click);
			// 
			// btnRecNo
			// 
			this.btnRecNo.Location = new System.Drawing.Point(120, 120);
			this.btnRecNo.Name = "btnRecNo";
			this.btnRecNo.Size = new System.Drawing.Size(32, 16);
			this.btnRecNo.TabIndex = 10;
			this.btnRecNo.Text = "-->";
			this.btnRecNo.Click += new System.EventHandler(this.btnRecNo_Click);
			// 
			// btnCurrentDate
			// 
			this.btnCurrentDate.Location = new System.Drawing.Point(8, 160);
			this.btnCurrentDate.Name = "btnCurrentDate";
			this.btnCurrentDate.Size = new System.Drawing.Size(128, 24);
			this.btnCurrentDate.TabIndex = 11;
			this.btnCurrentDate.Text = "Insert Current Date";
			this.btnCurrentDate.Click += new System.EventHandler(this.btnCurrentDate_Click);
			// 
			// btnMarkError
			// 
			this.btnMarkError.Location = new System.Drawing.Point(32, 200);
			this.btnMarkError.Name = "btnMarkError";
			this.btnMarkError.TabIndex = 12;
			this.btnMarkError.Text = "Mark Error";
			this.btnMarkError.Click += new System.EventHandler(this.btnMarkError_Click);
			// 
			// btnRemoveError
			// 
			this.btnRemoveError.Location = new System.Drawing.Point(8, 240);
			this.btnRemoveError.Name = "btnRemoveError";
			this.btnRemoveError.Size = new System.Drawing.Size(152, 23);
			this.btnRemoveError.TabIndex = 15;
			this.btnRemoveError.Text = "Remove Error Highlighting";
			this.btnRemoveError.Click += new System.EventHandler(this.btnRemoveError_Click);
			// 
			// btnSaveDocument
			// 
			this.btnSaveDocument.Location = new System.Drawing.Point(24, 320);
			this.btnSaveDocument.Name = "btnSaveDocument";
			this.btnSaveDocument.Size = new System.Drawing.Size(112, 23);
			this.btnSaveDocument.TabIndex = 16;
			this.btnSaveDocument.Text = "Save Document";
			this.btnSaveDocument.Click += new System.EventHandler(this.btnSaveDocument_Click);
			// 
			// btnRemoveBookMarks
			// 
			this.btnRemoveBookMarks.Location = new System.Drawing.Point(8, 280);
			this.btnRemoveBookMarks.Name = "btnRemoveBookMarks";
			this.btnRemoveBookMarks.Size = new System.Drawing.Size(152, 23);
			this.btnRemoveBookMarks.TabIndex = 17;
			this.btnRemoveBookMarks.Text = "Remove bookmarks";
			this.btnRemoveBookMarks.Click += new System.EventHandler(this.btnRemoveBookMarks_Click);
			// 
			// btnPrintView
			// 
			this.btnPrintView.Location = new System.Drawing.Point(24, 368);
			this.btnPrintView.Name = "btnPrintView";
			this.btnPrintView.Size = new System.Drawing.Size(120, 23);
			this.btnPrintView.TabIndex = 18;
			this.btnPrintView.Text = "Print Layout View";
			this.btnPrintView.Click += new System.EventHandler(this.btnPrintView_Click);
			// 
			// btnNormalView
			// 
			this.btnNormalView.Location = new System.Drawing.Point(24, 400);
			this.btnNormalView.Name = "btnNormalView";
			this.btnNormalView.Size = new System.Drawing.Size(120, 23);
			this.btnNormalView.TabIndex = 19;
			this.btnNormalView.Text = "Normal View";
			this.btnNormalView.Click += new System.EventHandler(this.btnNormalView_Click);
			// 
			// btnWebView
			// 
			this.btnWebView.Location = new System.Drawing.Point(24, 432);
			this.btnWebView.Name = "btnWebView";
			this.btnWebView.Size = new System.Drawing.Size(120, 23);
			this.btnWebView.TabIndex = 20;
			this.btnWebView.Text = "Web View";
			this.btnWebView.Click += new System.EventHandler(this.btnWebView_Click);
			// 
			// btnShowMenuBar
			// 
			this.btnShowMenuBar.Location = new System.Drawing.Point(16, 472);
			this.btnShowMenuBar.Name = "btnShowMenuBar";
			this.btnShowMenuBar.Size = new System.Drawing.Size(136, 23);
			this.btnShowMenuBar.TabIndex = 21;
			this.btnShowMenuBar.Text = "Show MenuBar";
			this.btnShowMenuBar.Click += new System.EventHandler(this.btnShowMenuBar_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(712, 517);
			this.Controls.Add(this.btnShowMenuBar);
			this.Controls.Add(this.btnWebView);
			this.Controls.Add(this.btnNormalView);
			this.Controls.Add(this.btnPrintView);
			this.Controls.Add(this.btnRemoveBookMarks);
			this.Controls.Add(this.btnSaveDocument);
			this.Controls.Add(this.btnRemoveError);
			this.Controls.Add(this.btnMarkError);
			this.Controls.Add(this.btnCurrentDate);
			this.Controls.Add(this.btnRecNo);
			this.Controls.Add(this.btnClientName);
			this.Controls.Add(this.txtRecNo);
			this.Controls.Add(this.txtClientName);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.objWinWordControl);
			this.Controls.Add(this.button1);
			this.Name = "frmMain";
			this.Text = "Main";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.frmMain_Closing);
			this.Load += new System.EventHandler(this.frmMain_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		private void frmMain_Load(object sender, System.EventArgs e)
		{
		}

		/// <summary>
		/// Loads the document. If it is already loaded, it will first unload and load again.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void button1_Click(object sender, System.EventArgs e)
		{

			string filNm;
			openFileDialog1.Multiselect = false;
			openFileDialog1.Filter = "MS-Word Files (*.doc,*.dot) | *.doc;*.dot";
			if(openFileDialog1.ShowDialog() == DialogResult.OK)
			{
            filNm = openFileDialog1.FileName;
			}
			else return;
			MessageBox.Show("Please wait while the document is being displayed");
			try
			{
				objWinWordControl.CloseControl();

			}
			catch{}
			finally
			{ 
				objWinWordControl.document=null;
				WinWordControl.WinWordControl.wd=null;
				WinWordControl.WinWordControl.wordWnd=0;
			}
			try
			{

				//Load the template used for testing.
				objWinWordControl.LoadDocument(filNm);
			}
			catch(Exception ex){String err = ex.Message;}
			btnClientName.Enabled=true;
			btnRecNo.Enabled=true;
			btnCurrentDate.Enabled=true;
		}

		private void frmMain_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			objWinWordControl.RestoreCommandBars();
			objWinWordControl.CloseControl();
		}

		
		/// <summary>
		/// Searches the bookmark by name and places text at the text
		/// </summary>
		/// <param name="BookMarkName"></param>
		/// <param name="BookMarkText"></param>
 
		private void WriteToBookMark(string BookMarkName, string BookMarkText)
		{
			try
			{
				Word.Document wd = objWinWordControl.document;
				Word.Application wa = wd.Application;
				int bookmark_cnt = wd.Bookmarks.Count;
				int i;
				for(i=1;i<=bookmark_cnt;i++)
				{
					object o = (object)i;
					if(BookMarkName.ToLower().Trim() == wd.Bookmarks.Item(ref o).Name.ToLower().Trim())
					{
						wd.Bookmarks.Item(ref o).Select();
						wa.Selection.TypeText(BookMarkText);
					}
				}
			}
			catch(Exception ex)
			{
				String err = ex.Message;
			}
		}


		/// <summary>
		/// Custom: Writes the client name at the bookmark.
		/// This template is pre-defined with 3 bookmarks.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnClientName_Click(object sender, System.EventArgs e)
		{
			WriteToBookMark("bmrkClientName",txtClientName.Text);
			btnClientName.Enabled=false;
		}

		/// <summary>
		/// Custom: Writes the client name at the bookmark.
		/// This template is pre-defined with 3 bookmarks.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnRecNo_Click(object sender, System.EventArgs e)
		{
			WriteToBookMark("bmrkRecNo",txtRecNo.Text);
			btnRecNo.Enabled=false;
		}

		/// <summary>
		/// Custom: Writes the client name at the bookmark.
		/// This template is pre-defined with 3 bookmarks.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnCurrentDate_Click(object sender, System.EventArgs e)
		{
			WriteToBookMark("bmrkCurrentDate",DateTime.Now.ToString());
			btnCurrentDate.Enabled=false;
		}


		/// <summary>
		/// Mark the error by selecting some text
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnMarkError_Click(object sender, System.EventArgs e)
		{
			try
			{
				string strText = objWinWordControl.document.Application.Selection.Text;
				frmMarkError f= new frmMarkError();
				f.txtChanged.Text = strText;
				f.txtOriginal.Text = strText;
				DialogResult dr= f.ShowDialog();

				if(dr==DialogResult.OK)
				{
					objWinWordControl.document.Application.Selection.Text=f.txtChanged.Text;
					objWinWordControl.document.Application.Selection.FormattedText.HighlightColorIndex=Word.WdColorIndex.wdYellow;
					string bkmrkname = "bkmrk_err_" + DateTime.Now.Day.ToString().PadLeft(2,'0') + DateTime.Now.Month.ToString().PadLeft(2,'0')+ DateTime.Now.Year.ToString()+ DateTime.Now.Hour.ToString().PadLeft(2,'0')+ DateTime.Now.Minute.ToString().PadLeft(2,'0')+ DateTime.Now.Second.ToString().PadLeft(2,'0')+ DateTime.Now.Ticks.ToString().PadLeft(8,'0');
					object o = objWinWordControl.document.Application.Selection.Range;
					objWinWordControl.document.Bookmarks.Add(bkmrkname,ref o);
					objWinWordControl.document.Application.Selection.FormattedText.HighlightColorIndex=Word.WdColorIndex.wdYellow;
				}

				// Do something else like making entry to database.
			}
			catch{}
		}

		/// <summary>
		/// Remove the Error bookmarks
		/// This might be required if the document is being sent for further quality check.
		/// In that case, the errors marked by current QA must not be shown to next QA
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnRemoveError_Click(object sender, System.EventArgs e)
		{
			try
			{
				string BookMarkName="";
				Word.Document wd = objWinWordControl.document;
				Word.Application wa = wd.Application;
				int bookmark_cnt = wd.Bookmarks.Count;
				int i;
				for(i=1;i<=bookmark_cnt;i++)
				{
					object o = (object)i;
					BookMarkName=wd.Bookmarks.Item(ref o).Name;
					if(BookMarkName.Substring(0,10)=="bkmrk_err_")
					{
						wd.Bookmarks.Item(ref o).Select();
						wa.Selection.FormattedText.HighlightColorIndex = Word.WdColorIndex.wdNoHighlight;
					}
				}

				//Do something else
			}
			catch(Exception ex)
			{
				String err = ex.Message;
			}		
		}

		/// <summary>
		/// Save the document. Calls the Word's save method
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnSaveDocument_Click(object sender, System.EventArgs e)
		{
			try
			{
				objWinWordControl.document.Save();
			}
			catch
			{}
		}

		/// <summary>
		/// Clear all the bookmarks. 
		/// This may be required before submitting the transcript to the client.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnRemoveBookMarks_Click(object sender, System.EventArgs e)
		{
			try
			{
				Word.Document wd = objWinWordControl.document;
				Word.Application wa = wd.Application;
				int bookmark_cnt = wd.Bookmarks.Count;
				int i;
				for(i=1;i<=bookmark_cnt;i++)
				{
					object o = (object)wd.Bookmarks.Count;
					wd.Bookmarks.Item(ref o).Delete();
				}

				MessageBox.Show("Bookmarks removed");
			}
			catch(Exception ex)
			{
				String err = ex.Message;
				MessageBox.Show("Error occured while removing bookmarks");
			}		
		}

		/// <summary>
		/// Change the view
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnPrintView_Click(object sender, System.EventArgs e)
		{
			try
			{
				objWinWordControl.document.ActiveWindow.ActivePane.View.Type = Word.WdViewType.wdPrintView;
			}
			catch{}
		}


		/// <summary>
		/// Change the view
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnNormalView_Click(object sender, System.EventArgs e)
		{
			try
			{
				objWinWordControl.document.ActiveWindow.ActivePane.View.Type = Word.WdViewType.wdNormalView;
			}
			catch{}
		}


		/// <summary>
		/// Change the view
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnWebView_Click(object sender, System.EventArgs e)
		{
			try
			{
				objWinWordControl.document.ActiveWindow.ActivePane.View.Type = Word.WdViewType.wdWebView;
			}
			catch{}
		}

		/// <summary>
		/// If you want to show the menubar to the user. 
		/// (Useful in cases where too many functionalities of word are being used)
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnShowMenuBar_Click(object sender, System.EventArgs e)
		{
			try
			{
				objWinWordControl.document.ActiveWindow.Application.CommandBars["Menu Bar"].Enabled=true;
			}
			catch{}
		}
		
	}
}



/*
 
 

*/